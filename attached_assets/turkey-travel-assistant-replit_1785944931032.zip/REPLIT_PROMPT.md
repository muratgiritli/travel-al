# Replit Prompt — Turkey Travel Assistant

Copy everything below into Replit Agent.

---

I uploaded a Turkey Travel Assistant project with country seed JSON files.

## Goal
Build/run a chat-style assistant for Türkiye travel rules.

There are **2 country categories** in data (NOT shown as UI tabs):
1. `visa_exempt` → 97 countries (`data/visa-exempt-countries.json`)
2. `evisa_direct` → 19 countries (`data/evisa-direct-countries.json`)

The visitor only selects a **country**. The app detects the category from the country record automatically.

## UI rules (important)
- Chat UI like a mobile assistant: gold mosque logo, title “Turkey Travel Assistant”, Online status
- **NO category toggle buttons** (do NOT show “Visa exempt / Direct e-Visa” pills in the chat footer)
- Only country dropdown + Check + message input
- Country name/flag always dynamic

### If country is visa_exempt
- Green pill with visa summary
- Orange pill: `Insurance required`
- Headline about mandatory travel insurance
- CTA: `Get travel insurance` → `/checkout`

### If country is evisa_direct
- Blue pill with e-Visa summary
- Orange pill: `Insurance required`
- Headline: need e-Visa + insurance mandatory
- CTA under the card: **`APPLY NOW`**
- `APPLY NOW` must go to internal `/next` page only
- **Do NOT redirect to evisa.gov.tr**

### `/next` page
Placeholder for now:
- Title: APPLY NOW
- Text: stay inside this assistant, no evisa.gov.tr redirect
- e-Visa + insurance steps will be built later
- Back to chat

## Admin
- `/admin.html` password from env `ADMIN_PASSWORD` (default `admin123`)
- Edit per country:
  - visa_summary
  - stay_rule
  - ai_extra_context
  - admin_html_notes (HTML shown under card)
- Admin may filter by category; public chat must not.

## Data
Use these seed files exactly:
- `data/visa-exempt-countries.json`
- `data/evisa-direct-countries.json`
- `data/country-overrides.json` for admin saves

## Commands
1. `npm install`
2. `npm start`
3. Fix errors until Run works
4. Give me the public URL

Do not rebuild from scratch unless broken. Prefer fixing the uploaded project.
