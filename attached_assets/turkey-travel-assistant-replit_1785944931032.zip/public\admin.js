let password = sessionStorage.getItem("tta_admin") || "";
let countries = [];
let currentId = "";
let selectedCategory = "all";

const loginView = document.getElementById("loginView");
const adminView = document.getElementById("adminView");
const passwordInput = document.getElementById("passwordInput");
const loginBtn = document.getElementById("loginBtn");
const loginError = document.getElementById("loginError");
const countryList = document.getElementById("countryList");
const searchInput = document.getElementById("searchInput");
const editTitle = document.getElementById("editTitle");
const visaSummary = document.getElementById("visaSummary");
const stayRule = document.getElementById("stayRule");
const aiContext = document.getElementById("aiContext");
const adminHtml = document.getElementById("adminHtml");
const insuranceRequired = document.getElementById("insuranceRequired");
const saveBtn = document.getElementById("saveBtn");
const saveToast = document.getElementById("saveToast");
const previewCard = document.getElementById("previewCard");

function escapeHtml(str) {
  return String(str ?? "")
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;");
}

async function api(url, options = {}) {
  const res = await fetch(url, {
    ...options,
    headers: {
      "Content-Type": "application/json",
      "x-admin-password": password,
      ...(options.headers || {}),
    },
  });
  if (!res.ok) {
    throw new Error((await res.json().catch(() => ({}))).error || "Request failed");
  }
  return res.json();
}

function showAdmin() {
  loginView.hidden = true;
  adminView.hidden = false;
}

function renderList(filter = "") {
  const q = filter.toLowerCase();
  countryList.innerHTML = "";
  countries
    .filter(
      (c) =>
        !q ||
        c.name.toLowerCase().includes(q) ||
        (c.name_tr || "").toLowerCase().includes(q),
    )
    .forEach((c) => {
      const btn = document.createElement("button");
      btn.type = "button";
      btn.className = c.id === currentId ? "active" : "";
      const tag = c.category === "evisa_direct" ? "e-Visa" : "Exempt";
      btn.textContent = `${c.flag_emoji} ${c.name} (${tag})`;
      btn.onclick = () => selectCountry(c.id);
      countryList.appendChild(btn);
    });
}

function renderPreview(card) {
  const pillClass = card.category === "evisa_direct" ? "blue" : "green";
  const cta = card.cta || (card.category === "evisa_direct" ? "APPLY NOW" : "Get travel insurance");

  previewCard.innerHTML = `
    <div class="card">
      <div class="flags">
        <span>${card.flag_emoji || ""} ${escapeHtml(card.country)}</span>
        <span class="arrow">→</span>
        <span>🇹🇷 Türkiye</span>
      </div>
      <div class="pills">
        <span class="pill ${pillClass}">${escapeHtml(card.visa_status)}</span>
        ${card.insurance_required ? '<span class="pill orange">Insurance required</span>' : ""}
      </div>
      <h2>${escapeHtml(card.headline)}</h2>
      ${(card.body || []).map((p) => `<p>${escapeHtml(p)}</p>`).join("")}
      <a class="btn" href="${escapeHtml(card.cta_href || "#")}">${escapeHtml(cta)}</a>
      ${card.admin_html_notes ? `<div class="admin-html">${card.admin_html_notes}</div>` : ""}
    </div>
  `;
}

async function selectCountry(id) {
  currentId = id;
  renderList(searchInput.value);
  const data = await api(`/api/admin/countries/${id}`);
  const c = data.country;
  editTitle.textContent = `${c.flag_emoji} ${c.name}`;
  visaSummary.value = c.visa_summary || "";
  stayRule.value = c.stay_rule || "";
  aiContext.value = c.ai_extra_context || "";
  adminHtml.value = c.admin_html_notes || "";
  insuranceRequired.checked = !!c.insurance_required;
  renderPreview(data.card);
}

async function loadCountries() {
  const data = await api(
    `/api/admin/countries?category=${encodeURIComponent(selectedCategory)}`,
  );
  countries = data.countries;
  renderList(searchInput.value);
  if (countries[0]) {
    selectCountry(countries[0].id);
  } else {
    currentId = "";
    editTitle.textContent = "No countries in this filter";
    previewCard.innerHTML = "";
  }
}

async function login() {
  password = passwordInput.value.trim();
  try {
    await loadCountries();
    sessionStorage.setItem("tta_admin", password);
    showAdmin();
  } catch {
    loginError.textContent = "Wrong password.";
  }
}

async function save() {
  if (!currentId) return;
  saveToast.style.color = "#166534";
  saveToast.textContent = "Saving...";
  const data = await api(`/api/admin/countries/${currentId}`, {
    method: "PUT",
    body: JSON.stringify({
      visa_summary: visaSummary.value,
      stay_rule: stayRule.value,
      ai_extra_context: aiContext.value,
      admin_html_notes: adminHtml.value,
      insurance_required: insuranceRequired.checked,
    }),
  });
  saveToast.textContent = "Saved.";
  renderPreview(data.card);
  const idx = countries.findIndex((c) => c.id === currentId);
  if (idx >= 0) countries[idx] = data.country;
}

loginBtn.addEventListener("click", login);
passwordInput.addEventListener("keydown", (e) => {
  if (e.key === "Enter") login();
});
searchInput.addEventListener("input", () => renderList(searchInput.value));

document.querySelectorAll("#adminView .pill-btn").forEach((btn) => {
  btn.addEventListener("click", async () => {
    document.querySelectorAll("#adminView .pill-btn").forEach((b) => b.classList.remove("active"));
    btn.classList.add("active");
    selectedCategory = btn.dataset.category;
    await loadCountries();
  });
});

saveBtn.addEventListener("click", () =>
  save().catch((e) => {
    saveToast.textContent = e.message;
    saveToast.style.color = "#b91c1c";
  }),
);

if (password) {
  loadCountries()
    .then(showAdmin)
    .catch(() => {
      sessionStorage.removeItem("tta_admin");
      password = "";
    });
}
