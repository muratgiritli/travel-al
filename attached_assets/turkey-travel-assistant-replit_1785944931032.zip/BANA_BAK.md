# Acemi kurulum — sadece bunları yap

Hazır paket: `turkey-travel-assistant-replit.zip`

## Replit’e koyma (5 adım)

1. Bilgisayarda bu dosyayı bul:  
   `C:\Users\HUAWEİ\Projects\youtube-ai-automation\turkey-travel-assistant-replit.zip`
2. Tarayıcıda aç: https://replit.com  
   Google ile giriş yap.
3. Sağ üstten **Create Repl** / **+ Create** tıkla.
4. **Import from ZIP** / **Upload** seçeneğini seç.  
   Yoksa: **Import project** → ZIP yükle.  
   `turkey-travel-assistant-replit.zip` dosyasını sürükle-bırak.
5. Açılınca yeşil **Run** tuşuna bas.

Bitince üstte bir web adresi çıkar. Ona tıkla → chat açılır.

## Nasıl kullanılır?

1. Altta kategori seç:
   - **Visa exempt** = vize muaf (97 ülke)
   - **Direct e-Visa** = doğrudan e-Vize (19 ülke)
2. Ülkeyi seç (örnek: Germany veya Vietnam)
3. **Check** tuşuna bas
4. Kart çıkar:
   - Exempt → sigorta zorunlu → checkout
   - e-Visa → e-Vize + sigorta zorunlu → **Continue** (sonraki sayfa şimdilik placeholder)

## Admin (ülke bilgisi / HTML yazma)

1. Sohbet sağ üstünde **Admin**
2. Şifre: `admin123`
3. Ülke seç
4. Altta **Admin HTML notes** kutusuna HTML yaz  
   Örnek:
   ```html
   <p><strong>Germany tip:</strong> Keep insurance PDF offline for border checks.</p>
   ```
5. **Save country**

Bu HTML, o ülkeyi seçen ziyaretçinin kartının altında görünür.

## Şifre değiştirmek istersen

Replit’te **Secrets** / Tools → Secrets:
- Key: `ADMIN_PASSWORD`
- Value: istediğin şifre
