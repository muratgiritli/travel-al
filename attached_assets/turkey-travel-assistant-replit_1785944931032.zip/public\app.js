const chatEl = document.getElementById("chat");
const countrySelect = document.getElementById("countrySelect");
const messageInput = document.getElementById("messageInput");
const sendBtn = document.getElementById("sendBtn");
const checkBtn = document.getElementById("checkBtn");

let selectedCountryId = "";
let started = false;

function escapeHtml(str) {
  return String(str ?? "")
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;");
}

function scrollChat() {
  chatEl.scrollTop = chatEl.scrollHeight;
}

function addBot(text) {
  const row = document.createElement("div");
  row.className = "row bot";
  row.innerHTML = `<div class="avatar">🕌</div><div class="bubble bot">${escapeHtml(text)}</div>`;
  chatEl.appendChild(row);
  scrollChat();
}

function addUser(text) {
  const row = document.createElement("div");
  row.className = "row user";
  row.innerHTML = `<div class="bubble user">${escapeHtml(text)}</div>`;
  chatEl.appendChild(row);
  scrollChat();
}

function addSystem(text) {
  const el = document.createElement("div");
  el.className = "system";
  el.textContent = text;
  chatEl.appendChild(el);
  scrollChat();
}

function statusPillClass(card) {
  return card.category === "evisa_direct" ? "blue" : "green";
}

function ctaFor(card) {
  if (card.cta) return card.cta;
  return card.category === "evisa_direct" ? "APPLY NOW" : "Get travel insurance";
}

function hrefFor(card) {
  if (card.cta_href) return card.cta_href;
  return card.category === "evisa_direct" ? "/next" : "/checkout";
}

function renderCard(card) {
  const wrap = document.createElement("div");
  wrap.className = "card";

  const icons =
    card.category === "evisa_direct" ? ["🛂", "🛡️", "➡️"] : ["🛡️", "📄", "✅"];

  const features = (card.features || [])
    .map(
      (f, i) =>
        `<div class="feature"><div class="ico">${icons[i] || "•"}</div><div>${escapeHtml(f)}</div></div>`,
    )
    .join("");

  const href = hrefFor(card);
  const cta = ctaFor(card);

  wrap.innerHTML = `
    <div class="flags">
      <span>${card.flag_emoji || ""} ${escapeHtml(card.country)}</span>
      <span class="arrow">→</span>
      <span>🇹🇷 Türkiye</span>
    </div>
    <div class="pills">
      <span class="pill ${statusPillClass(card)}">${escapeHtml(card.visa_status)}</span>
      ${card.insurance_required ? '<span class="pill orange">Insurance required</span>' : ""}
    </div>
    <h2>${escapeHtml(card.headline)}</h2>
    ${(card.body || []).map((p) => `<p>${escapeHtml(p)}</p>`).join("")}
    <div class="features">${features}</div>
    <div class="price">
      <strong>${escapeHtml(card.price_label || "")}</strong>
      <small>${escapeHtml(card.price_example || "")}</small>
    </div>
    <a class="btn" href="${escapeHtml(href)}">${escapeHtml(cta)}</a>
    <button class="link" type="button" data-ask>Ask a question</button>
    <div class="card-foot">
      ${
        card.category === "evisa_direct"
          ? "Apply here • Insurance mandatory • No redirect to evisa.gov.tr"
          : "Instant PDF • Border-ready • Cancel anytime"
      }
    </div>
    ${card.admin_html_notes ? `<div class="admin-html">${card.admin_html_notes}</div>` : ""}
  `;

  chatEl.appendChild(wrap);
  scrollChat();

  const ask = wrap.querySelector("[data-ask]");
  if (ask) {
    ask.onclick = () => {
      messageInput.focus();
      messageInput.placeholder = "Ask about visa, e-Visa, insurance, stay length...";
    };
  }
}

async function loadCountries() {
  const res = await fetch("/api/countries?category=all");
  const data = await res.json();
  countrySelect.innerHTML = '<option value="">Select your passport country…</option>';
  for (const c of data.countries) {
    const opt = document.createElement("option");
    opt.value = c.id;
    opt.textContent = `${c.flag_emoji} ${c.name}`;
    countrySelect.appendChild(opt);
  }
  selectedCountryId = "";
}

function selectedCountryName() {
  const text = countrySelect.options[countrySelect.selectedIndex]?.text || "";
  return text.replace(/^[^\s]+\s/, "");
}

async function runCheck() {
  const id = countrySelect.value;
  if (!id) {
    addBot("Please select your passport country first.");
    return;
  }

  const name = selectedCountryName();
  if (selectedCountryId !== id) {
    selectedCountryId = id;
    addUser(`I have a ${name} passport.`);
    addSystem("Passport selected.");
  }

  addUser("Do I need a visa for Turkey?");

  const res = await fetch("/api/chat", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      countryId: id,
      message: "Do I need a visa for Turkey?",
    }),
  });
  const data = await res.json();
  addBot(data.reply_text);
  if (data.card) renderCard(data.card);
}

async function sendMessage() {
  const text = messageInput.value.trim();
  if (!text) return;

  if (!selectedCountryId) {
    addBot("Select your passport country first, then ask your question.");
    return;
  }

  addUser(text);
  messageInput.value = "";

  const res = await fetch("/api/chat", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ countryId: selectedCountryId, message: text }),
  });
  const data = await res.json();
  addBot(data.reply_text);

  if (data.card && /visa|e-visa|evisa|insurance|sigorta|need|apply/i.test(text)) {
    renderCard(data.card);
  }
}

function boot() {
  if (started) return;
  started = true;
  addBot("Welcome. I can check visa rules for Türkiye. Which passport do you hold?");
}

countrySelect.addEventListener("change", () => {
  selectedCountryId = countrySelect.value;
});

checkBtn.addEventListener("click", runCheck);
sendBtn.addEventListener("click", sendMessage);
messageInput.addEventListener("keydown", (e) => {
  if (e.key === "Enter") sendMessage();
});

loadCountries().then(boot);
