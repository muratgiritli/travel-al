# Replit Prompt — Sticker / Mission Visa Pages (67 countries)

Copy everything below into Replit Agent.

---

Build **Sticker Visa (embassy/mission visa)** country pages for Turkey Travel Assistant.

## Category
`sticker_mission` — **67 countries** from:
`data/sticker-mission-countries.json`

These passports generally **cannot use direct e-Visa**. They need a **Turkish embassy/consulate sticker visa** (or consultancy support for that process).

## Routing
- `/` = passport country picker only (NOT `/visa` landing)
- Selecting a sticker-mission country opens `/{slug}`  
  Examples: `/nigeria`, `/somalia`, `/kenya`, `/syria`
- Do **NOT** redirect to evisa.gov.tr
- All **APPLY NOW** buttons go internal: `/next` or `/apply/{slug}`
- Country name always dynamic

## Page goal
A clear “Sticker Visa Consultancy” landing page (similar support card style on evisacity), focused on embassy-stamped visas.

### Hero
- Pills: `TURKEY` + `{COUNTRY}`
- H1: `Embassy Sticker Visa`
- H2: `for {Country} Citizens`
- Short text: online e-Visa is not available for this passport category; mission/embassy process is required

### Requirements card
- Passport validity: minimum 180 days
- Visa type: Sticker visa via Turkish mission
- Show country-specific note from `mission_note` / `stay_rule` when present
- Orange badge: `Insurance required`

### Main option cards

**OPTION 1 — Sticker Visa Consultancy Service** (primary)
- Price: `$20 USD` (configurable)
- Title: Sticker Visa Consultancy Service
- Text: Consultancy for Embassy-stamped visas
- Bullets:
  - Country-specific document preparation and audit
  - Consular appointment coordination and scheduling
  - Application form assistance and biometric process support
  - 24/7 tracking from passport submission to visa approval
- CTA: `APPLY NOW`

**OPTION 2 — Guided application support** (optional second card)
- Explain we guide the Turkish mission application inside our assistant
- Insurance required for travel
- CTA: `APPLY NOW`

### Important copy rules
- Say clearly: **No direct e-Visa** for this nationality (ordinary passport)
- Application is through Turkish embassy/consulate process with our consultancy
- Never send user to evisa.gov.tr
- Keep tone helpful and official

### UI
- Mobile-first
- Bottom nav: Home / Track / FAQ / Contact
- Floating AI chat button for that country
- Same visual language as other country pages

### Data / admin
Use `data/sticker-mission-countries.json` (67 countries).  
Admin can edit:
- mission_note / stay_rule
- prices/texts
- admin_html_notes
- ai_extra_context

### Acceptance
1. `/` picker works
2. Any of the 67 sticker countries opens `/{slug}` sticker page
3. APPLY NOW is internal only
4. No evisa.gov.tr links
5. `npm start` works + give public URL
