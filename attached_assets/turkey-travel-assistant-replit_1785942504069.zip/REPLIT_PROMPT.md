# Replit Prompt — Turkey Travel Assistant (Visa Exempt)

Copy everything below into Replit Agent.

---

Build a production-ready web app called **Turkey Travel Assistant**.

## Goal
When a visitor selects a **visa-exempt** country, show a **chat-style UI**. The AI answer must appear as a rich in-chat card. Country name must always be dynamic.

Start with **Category 1 only: Visa Exempt (97 countries)**.

Use the seed file already provided at:
`data/visa-exempt-countries.json`

---

## Core UX (must match chat UI style)

### Header
- Gold circular logo (mosque + crescent)
- Title: `Turkey Travel Assistant`
- Green status: `Online`
- Language dropdown: `EN`
- Menu (three dots)

### Chat flow
1. Bot: `Welcome. I can check visa rules for Türkiye. Which passport do you hold?`
2. User selects a country from searchable dropdown (seeded from JSON)
3. Center system chip: `Passport selected.`
4. User: `Do I need a visa for Turkey?`
5. Bot short text (dynamic):
   `{Country} is visa-exempt for Türkiye. But travel health insurance is mandatory for your stay.`
6. Then render the rich card inside the chat.

### Rich card structure
- Flags row: `{flag} {Country}` → `🇹🇷 Türkiye`
- Green pill: use country `visa_summary`
- Orange pill: `Insurance required`
- Headline: `Travel insurance is required for your stay`
- Body:
  - country `stay_rule`
  - `However, travel insurance covering the full length of your stay is mandatory.`
- Features:
  - Shield: `Turkish Law compliant`
  - Document: `Instant digital PDF policy`
  - Check: `Coverage for full stay length`
- Pricing box:
  - `Standard Plan • $5 / day`
  - `Example: 10 days × 1 traveler = $50`
- Primary CTA (navy): `Get travel insurance` → `/checkout` placeholder
- Secondary: `Ask a question`
- Footer: `Instant PDF • Border-ready • Cancel anytime`
- If `admin_html_notes` exists, render sanitized HTML below the card

### Bottom bar
- Input placeholder: `Message Turkey Travel Assistant...`
- Paperclip + mic + navy send button
- Footer: `AI guidance • Human travel experts available.`

### Design tokens
- Navy: `#0A1F44`
- Gold: `#C5A059`
- Green badge bg `#E6F4EA`
- Orange badge bg `#FFF4E5`
- Mobile-first + desktop centered chat window
- Clean sans-serif, rounded cards, soft borders

---

## Data
Seed all countries from `data/visa-exempt-countries.json`.

Fields per country:
- id, name, name_tr, iso2, flag_emoji
- category = visa_exempt
- visa_summary, stay_rule
- insurance_required = true
- admin_html_notes (HTML, editable in admin)
- ai_extra_context (editable in admin)
- is_active

Merge missing fields from JSON `defaults`.

Country name must be injected dynamically in:
- chat bubbles
- card
- AI responses
- admin preview

---

## Admin panel (`/admin`)
Password-protected (env `ADMIN_PASSWORD`).

1. Countries list with search
2. Country edit:
   - name, iso2, flag, visa_summary, stay_rule, insurance_required
   - HTML editor for `admin_html_notes` + live preview
   - textarea for `ai_extra_context`
3. Live chat-card preview for selected country

---

## AI chat endpoint
`POST /api/chat`

Return structured JSON:
```json
{
  "reply_text": "...",
  "card": {
    "country": "Germany",
    "iso2": "DE",
    "flag_emoji": "🇩🇪",
    "visa_status": "Visa exempt • 90 days / 180",
    "insurance_required": true,
    "headline": "Travel insurance is required for your stay",
    "body": ["...", "..."],
    "features": ["Turkish Law compliant", "Instant digital PDF policy", "Coverage for full stay length"],
    "price_label": "Standard Plan • $5 / day",
    "price_example": "Example: 10 days × 1 traveler = $50",
    "cta": "Get travel insurance",
    "admin_html_notes": "<p>...</p>"
  }
}
```

Rules:
- Always confirm visa-exempt
- Always say insurance is mandatory
- Use admin_html_notes + ai_extra_context when present
- Never contradict seeded visa category
- English UI first

---

## Tech
- Next.js or React + Node/Express
- SQLite
- Tailwind CSS
- DOMPurify for HTML notes
- One-click runnable on Replit

## Acceptance
- Any of the 97 countries shows chat flow + card
- Country always dynamic
- Admin HTML notes editable and used by AI
- Mobile + desktop polished
- CTA goes to `/checkout` placeholder
- Only Visa Exempt category for now
