const express = require("express");
const fs = require("fs");
const path = require("path");
const sanitizeHtml = require("sanitize-html");

const app = express();
const PORT = process.env.PORT || 3000;
const ROOT = __dirname;
const SEED_PATH = path.join(ROOT, "data", "visa-exempt-countries.json");
const OVERRIDES_PATH = path.join(ROOT, "data", "country-overrides.json");
const ADMIN_PASSWORD = process.env.ADMIN_PASSWORD || "admin123";

app.use(express.json({ limit: "2mb" }));
app.use(express.static(path.join(ROOT, "public")));

function readJson(file, fallback) {
  try {
    return JSON.parse(fs.readFileSync(file, "utf8"));
  } catch {
    return fallback;
  }
}

function writeJson(file, data) {
  fs.writeFileSync(file, JSON.stringify(data, null, 2), "utf8");
}

function loadCountries() {
  const seed = readJson(SEED_PATH, { defaults: {}, countries: [] });
  const overrides = readJson(OVERRIDES_PATH, {});
  const defaults = seed.defaults || {};

  return (seed.countries || []).map((c) => {
    const o = overrides[c.id] || {};
    return {
      ...defaults,
      ...c,
      ...o,
      category: "visa_exempt",
      insurance_required:
        o.insurance_required ?? c.insurance_required ?? defaults.insurance_required ?? true,
      admin_html_notes: o.admin_html_notes ?? c.admin_html_notes ?? "",
      ai_extra_context: o.ai_extra_context ?? c.ai_extra_context ?? "",
      is_active: o.is_active ?? c.is_active ?? true,
    };
  });
}

function getCountry(idOrIso) {
  const key = String(idOrIso || "").toLowerCase();
  return loadCountries().find(
    (c) => c.id === key || c.iso2.toLowerCase() === key || c.name.toLowerCase() === key,
  );
}

function buildCard(country) {
  const defaults = readJson(SEED_PATH, { defaults: {} }).defaults || {};
  return {
    country: country.name,
    name_tr: country.name_tr,
    iso2: country.iso2,
    flag_emoji: country.flag_emoji,
    visa_status: country.visa_summary || defaults.visa_summary,
    insurance_required: !!country.insurance_required,
    headline: country.headline || defaults.headline,
    body: [
      country.stay_rule || defaults.stay_rule,
      "However, travel insurance covering the full length of your stay is mandatory.",
    ],
    features: country.features || defaults.features,
    price_label: country.price_label || defaults.price_label,
    price_example: country.price_example || defaults.price_example,
    cta: country.cta || defaults.cta,
    admin_html_notes: sanitizeHtml(country.admin_html_notes || "", {
      allowedTags: sanitizeHtml.defaults.allowedTags.concat(["img", "h1", "h2"]),
      allowedAttributes: {
        ...sanitizeHtml.defaults.allowedAttributes,
        img: ["src", "alt"],
        a: ["href", "name", "target", "rel"],
      },
    }),
    ai_extra_context: country.ai_extra_context || "",
  };
}

function requireAdmin(req, res, next) {
  const token = req.headers["x-admin-password"] || req.query.password;
  if (token !== ADMIN_PASSWORD) {
    return res.status(401).json({ error: "Unauthorized" });
  }
  next();
}

app.get("/api/countries", (_req, res) => {
  const countries = loadCountries()
    .filter((c) => c.is_active)
    .map((c) => ({
      id: c.id,
      name: c.name,
      name_tr: c.name_tr,
      iso2: c.iso2,
      flag_emoji: c.flag_emoji,
      visa_summary: c.visa_summary,
    }))
    .sort((a, b) => a.name.localeCompare(b.name));
  res.json({ count: countries.length, countries });
});

app.get("/api/countries/:id", (req, res) => {
  const country = getCountry(req.params.id);
  if (!country) return res.status(404).json({ error: "Country not found" });
  res.json({ country, card: buildCard(country) });
});

app.post("/api/chat", (req, res) => {
  const { countryId, message } = req.body || {};
  const country = getCountry(countryId);
  if (!country) {
    return res.status(400).json({
      reply_text: "Please select your passport country first.",
      card: null,
    });
  }

  const card = buildCard(country);
  const lower = String(message || "").toLowerCase();
  let reply_text = `${country.name} is visa-exempt for Türkiye. But travel health insurance is mandatory for your stay.`;

  if (lower.includes("insurance") || lower.includes("sigorta")) {
    reply_text = `Yes — travel insurance is required for ${country.name} passport holders entering Türkiye, even though you are visa-exempt.`;
  } else if (lower.includes("how long") || lower.includes("days")) {
    reply_text = `${country.name}: ${card.visa_status}. ${card.body[0]}`;
  } else if (country.ai_extra_context) {
    reply_text = `${reply_text}\n\nNote: ${country.ai_extra_context}`;
  }

  res.json({ reply_text, card });
});

app.get("/api/admin/countries", requireAdmin, (_req, res) => {
  res.json({ countries: loadCountries().sort((a, b) => a.name.localeCompare(b.name)) });
});

app.get("/api/admin/countries/:id", requireAdmin, (req, res) => {
  const country = getCountry(req.params.id);
  if (!country) return res.status(404).json({ error: "Country not found" });
  res.json({ country, card: buildCard(country) });
});

app.put("/api/admin/countries/:id", requireAdmin, (req, res) => {
  const country = getCountry(req.params.id);
  if (!country) return res.status(404).json({ error: "Country not found" });

  const overrides = readJson(OVERRIDES_PATH, {});
  const prev = overrides[country.id] || {};
  const body = req.body || {};

  overrides[country.id] = {
    ...prev,
    visa_summary: body.visa_summary ?? prev.visa_summary ?? country.visa_summary,
    stay_rule: body.stay_rule ?? prev.stay_rule ?? country.stay_rule,
    insurance_required:
      body.insurance_required ?? prev.insurance_required ?? country.insurance_required,
    admin_html_notes: body.admin_html_notes ?? prev.admin_html_notes ?? "",
    ai_extra_context: body.ai_extra_context ?? prev.ai_extra_context ?? "",
    is_active: body.is_active ?? prev.is_active ?? true,
  };

  writeJson(OVERRIDES_PATH, overrides);
  const updated = getCountry(country.id);
  res.json({ ok: true, country: updated, card: buildCard(updated) });
});

app.get("/checkout", (_req, res) => {
  res.sendFile(path.join(ROOT, "public", "checkout.html"));
});

app.listen(PORT, () => {
  console.log(`Turkey Travel Assistant running on http://localhost:${PORT}`);
  console.log(`Admin: http://localhost:${PORT}/admin.html (password: ${ADMIN_PASSWORD})`);
});
