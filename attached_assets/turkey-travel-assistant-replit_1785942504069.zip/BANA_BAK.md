# Acemi kurulum — sadece bunları yap

Hazır paket: `turkey-travel-assistant-replit.zip`

## Replit’e koyma (5 adım)

1. Bilgisayarda bu dosyayı bul:  
   `C:\Users\HUAWEİ\Projects\youtube-ai-automation\turkey-travel-assistant-replit.zip`
2. Tarayıcıda aç: https://replit.com  
   Google ile giriş yap.
3. Sağ üstten **Create Repl** / **+ Create** tıkla.
4. **Import from ZIP** / **Upload** seçeneğini seç.  
   Yoksa: **Import project** → ZIP yükle.  
   `turkey-travel-assistant-replit.zip` dosyasını sürükle-bırak.
5. Açılınca yeşil **Run** tuşuna bas.

Bitince üstte bir web adresi çıkar. Ona tıkla → chat açılır.

## Nasıl kullanılır?

1. Ülkeyi seç (örnek: Germany)
2. **Check** tuşuna bas
3. Vize muaf + sigorta zorunlu kartı çıkar
4. **Get travel insurance** ile checkout sayfasına gider

## Admin (ülke bilgisi / HTML yazma)

1. Sohbet sağ üstünde **Admin**
2. Şifre: `admin123`
3. Ülke seç
4. Altta **Admin HTML notes** kutusuna HTML yaz  
   Örnek:
   ```html
   <p><strong>Germany tip:</strong> Keep insurance PDF offline for border checks.</p>
   ```
5. **Save country**

Bu HTML, o ülkeyi seçen ziyaretçinin kartının altında görünür.

## Şifre değiştirmek istersen

Replit’te **Secrets** / Tools → Secrets:
- Key: `ADMIN_PASSWORD`
- Value: istediğin şifre
